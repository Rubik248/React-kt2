import style from './TextBlock.module.css'
function TextBlock() {
    return (
        <div className={style.block}>
            <p className={style.txt}>Приехав к нам однажды, многие наши клиенты становятся постоянными, а часть из них даже друзьями.А также в нашей мастерской можно отремонтировать электросамокат и электровелосипед.</p>
        </div>
    )
}
export default TextBlock