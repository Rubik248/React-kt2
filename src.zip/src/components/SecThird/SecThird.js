import s from './SecThird.module.css'


function SecThird(props) {

    const {title, color} = props

    return (
        <div className={s.wrapper} style={{backgroundColor:color}}>
            <div className={s.line}></div>
            <h2 className={s.title}>{title}</h2>
        </div>
    )
}

export default SecThird