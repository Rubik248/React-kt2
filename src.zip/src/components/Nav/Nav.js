import s from './Nav.module.css'

function Nav() {
    return (
        <div className={s.wrapper}>
            <a className={s.link} href="#">О нас</a>
            <a className={s.link}  href="#">Услуги</a>
            <a className={s.link} href="#">Аренда</a>
        </div>
    )
}

export default Nav