
import s from './About.module.css'


function About() {
    return (
        <div className={s.btn}>
            <a className={s.text} href="#">Связаться</a>
        </div>
    )
}

export default About