import style from "./Header.module.css"
import { ReactComponent as ImageLogo } from "./logo.svg"


function Header() {
    return (
        <div className={style.block}>
            <ImageLogo/>
            <div className={style.wrapper_link}>
                <a className={style.link}>О нас</a>
                <a className={style.link}>Услуги</a>
                <a className={style.link}>Аренда</a>
            </div>
            <div className={style.button}>
                <a className={style.button_text}>Связаться</a>
            </div>
        </div>
    )
}

export default Header
