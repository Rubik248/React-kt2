import Header from "../Header/Header"
import Section from '../Section/Section'
import TextBlock from "../TextBlock/TextBlock"
import AllBlock from "../AllBlock/AllBlock"



import dino from './dino.png'
import velo from './bike.png'
import veloTwo from './bike2.png'

function App() {
    return (
        <div>
            <Header/>
            <Section 
                title='Веломастерская “Велозар”' 
                text='Мы, мастера веломастерской «Велозар», как раз те самые счастливые люди, которые смогли превратить свое увлечение и хобби в профессию. Мы сами любим кататься и хотим чтобы Ваш двухколесный друг приносил Вам только радость и удовольствие от езды.' 
                image={dino} 
                backGround='rgba(244, 249, 226, 1)' 
                colorText='rgba(34, 53, 111, 1)'/>
            <Section 
                title='Что мы предлагаем' 
                text='В нашей мастерской можно выполнить комплексное техническое обслуживание велосипеда, ремонт и настройку всех его узлов, шиномонтажные работы. Вовремя проведенное ТО велосипеда помогает избежать многих проблем и дорогого ремонта. Все работы выполняем качественно и с душой.' 
                image={velo} 
                backGround='rgba(98, 208, 223, 1)' 
                colorText='rgba(255, 255, 255, 1)'/>
            <TextBlock/>
            <AllBlock/>
            <Section 
                title='Прокат велосипедов' 
                text='У нас вы можете взять на прокат хорошо обслуженные и настроенные велосипеды. Как раз мы находимся в прекрасном парке!' 
                image={veloTwo} 
                backGround='rgba(255, 255, 255, 1)' 
                colorText='rgba(34, 53, 111, 1)'/>
        </div>
    )
}
export default App