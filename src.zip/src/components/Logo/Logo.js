import { ReactComponent as Image } from "./logo copy 1.svg"


function Logo() {
    return (
        <Image/>
    )
}


export default Logo