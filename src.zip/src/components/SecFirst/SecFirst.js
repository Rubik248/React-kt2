import s from './SecFirst.module.css'

function SecFirst(props) {


    const {title, text, img, back, color} = props
    console.log(back)
    return (
        <div style={{backgroundColor: back}} className={s.wrapper}>
            <div className={s.txtWrapper}>
                <h2 style={{color: color}} className={s.title}>{title}</h2>
                <p style={{color: color}} className={s.text}>{text}</p>
            </div>
            <img alt="" src={img}/>
        </div>
    )
}

export default SecFirst