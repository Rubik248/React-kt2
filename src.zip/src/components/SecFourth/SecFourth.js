import SecThird from "../SecThird/SecThird"
import s from './SecFourth.module.css'


function SecFourth() {
    return (
        <div className={s.wrapper}>
           <SecThird title='Годовое ТО' color='rgba(34, 53, 111, 1)'/>
           <SecThird title='Выравнивание колес' color='rgba(0, 82, 193, 1)'/>
           <SecThird title='Настройка переключателей' color='rgba(118, 181, 139, 1)'/>
        </div>
    )
}

export default SecFourth