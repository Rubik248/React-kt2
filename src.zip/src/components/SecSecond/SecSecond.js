

import s from './SecSecond.module.css'

function SecSecond() {

    return (
        <div className={s.wrapper}>
            <p className={s.text}>Приехав к нам однажды, многие наши клиенты становятся постоянными, а часть из них даже друзьями. <br/>А также в нашей мастерской можно отремонтировать электросамокат и электровелосипед.</p>
        </div>
    )
}

export default SecSecond