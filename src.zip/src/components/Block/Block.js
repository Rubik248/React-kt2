import style from './Block.module.css'

function Block(props) {
    const {title, color} = props
    return (
        <div className={style.block} style={{backgroundColor:color}}>
            <div className={style.row}></div>
            <h2 className={style.title}>{title}</h2>
        </div>
    )
}
export default Block