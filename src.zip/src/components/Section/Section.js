import style from './Section.module.css'

function Section(props) {


    const {title, text, image, backGround, colorText} = props
    return (
        <div style={{backgroundColor: backGround}} className={style.block}>
            <div className={style.block_text}>
                <h2 style={{color: colorText}} className={style.title}>{title}</h2>
                <p style={{color: colorText}} className={style.txt}>{text}</p>
            </div>
            <img alt="" src={image}/>
        </div>
    )
}

export default Section