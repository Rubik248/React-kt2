import Block from "../Block/Block"
import s from './AllBlock.module.css'


function AllBlock() {
    return (
        <div className={s.wrapper}>
           <Block title='Годовое ТО' color='rgba(34, 53, 111, 1)'/>
           <Block title='Выравнивание колес' color='rgba(0, 82, 193, 1)'/>
           <Block title='Настройка переключателей' color='rgba(118, 181, 139, 1)'/>
        </div>
    )
}

export default AllBlock